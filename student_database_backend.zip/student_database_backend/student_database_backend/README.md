# Student Database Backend

Backend-only Spring Boot project for managing student records using MySQL.

## Features

- Add student
- View all students
- View student by ID
- Update student
- Delete student
- MySQL database storage
- Spring Boot REST API
- JPA Repository layer
- Service layer
- Controller layer

## Technologies Used

- Java 17
- Spring Boot 2.5.5
- Spring Data JPA
- MySQL
- Maven
- Spring Tool Suite

## Database Setup

Create the database manually in MySQL Workbench:

```sql
CREATE DATABASE student_database_db;
```

Tables will be created automatically by Spring Boot because:

```properties
spring.jpa.hibernate.ddl-auto=update
```

## MySQL Configuration

Edit this file if your MySQL port or password is different:

```text
src/main/resources/application.properties
```

Default configuration:

```properties
spring.datasource.url=jdbc:mysql://localhost:3307/student_database_db
spring.datasource.username=root
spring.datasource.password=Rollsroyce@12
```

## Run in Spring Tool Suite

1. Open Spring Tool Suite.
2. Go to File -> Import.
3. Select Maven -> Existing Maven Projects.
4. Choose this project folder.
5. Click Finish.
6. Right-click the project.
7. Select Run As -> Spring Boot App.

## API Endpoints

Base URL:

```text
http://localhost:8080/api/students
```

Endpoints:

```text
POST    /api/students
GET     /api/students
GET     /api/students/{id}
PUT     /api/students/{id}
DELETE  /api/students/{id}
```
