const API_BASE = "http://localhost:8080/api/employees";

if (sessionStorage.getItem("loggedIn") !== "true") {
    window.location.href = "index.html";
}

const employeeForm = document.getElementById("employeeForm");
const tableBody = document.getElementById("employeeTableBody");
const formTitle = document.getElementById("formTitle");
const submitBtn = document.getElementById("submitBtn");

async function loadEmployees() {
    const response = await fetch(API_BASE);
    const employees = await response.json();

    tableBody.innerHTML = "";

    employees.forEach(employee => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${employee.id}</td>
            <td>${employee.firstName} ${employee.lastName}</td>
            <td>${employee.email}</td>
            <td>${employee.phone || "-"}</td>
            <td>${employee.department || "-"}</td>
            <td>${employee.designation || "-"}</td>
            <td>${employee.salary || "-"}</td>
            <td>
                <button class="edit-btn" onclick='editEmployee(${JSON.stringify(employee)})'>Edit</button>
                <button class="delete-btn" onclick="deleteEmployee(${employee.id})">Delete</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

employeeForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const employeeId = document.getElementById("employeeId").value;

    const employee = {
        firstName: document.getElementById("firstName").value,
        lastName: document.getElementById("lastName").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        department: document.getElementById("department").value,
        designation: document.getElementById("designation").value,
        salary: Number(document.getElementById("salary").value)
    };

    if (employeeId) {
        await fetch(`${API_BASE}/${employeeId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(employee)
        });
    } else {
        await fetch(API_BASE, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(employee)
        });
    }

    resetForm();
    loadEmployees();
});

function editEmployee(employee) {
    document.getElementById("employeeId").value = employee.id;
    document.getElementById("firstName").value = employee.firstName;
    document.getElementById("lastName").value = employee.lastName;
    document.getElementById("email").value = employee.email;
    document.getElementById("phone").value = employee.phone || "";
    document.getElementById("department").value = employee.department || "";
    document.getElementById("designation").value = employee.designation || "";
    document.getElementById("salary").value = employee.salary || "";

    formTitle.textContent = "Update Employee";
    submitBtn.textContent = "Update Employee";
}

async function deleteEmployee(id) {
    if (confirm("Are you sure you want to delete this employee?")) {
        await fetch(`${API_BASE}/${id}`, { method: "DELETE" });
        loadEmployees();
    }
}

function resetForm() {
    employeeForm.reset();
    document.getElementById("employeeId").value = "";
    formTitle.textContent = "Add Employee";
    submitBtn.textContent = "Insert Employee";
}

function logout() {
    sessionStorage.clear();
    window.location.href = "index.html";
}

loadEmployees();
